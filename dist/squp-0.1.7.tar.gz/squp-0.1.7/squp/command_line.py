from . import start


def main():
    start()